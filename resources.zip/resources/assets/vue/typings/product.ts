declare interface Product {
  id: number;
  menu_id: number;
  category_id: number;
  name: string;
  description: string;
  price: string;
  image_src: any;
}
