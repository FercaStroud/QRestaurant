declare interface Payment {
  id: number;
  user_id: number;
  status: string;
}
