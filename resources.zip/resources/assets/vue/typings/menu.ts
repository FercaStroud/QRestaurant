declare interface Menu {
  id: number;
  name: string;
  description: string;
  image_src: any;
  type: string;
}
