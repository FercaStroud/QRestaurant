declare interface Category {
  id: number;
  menu_id: number;
  user_id: number; //BORRAR
  parent_id: number;
  name: string;
  description: string;
  image_src: any;
}
