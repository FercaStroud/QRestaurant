declare interface User {
  id: number;
  type_id: number;
  user_name: string;
  restaurant_name: string;
  logo_src: string;
  email: string;
  phone: string;
  city: string;
  type: string;
  state: string;
  address: string;
  password: string;
  password_confirmation: string;
}
