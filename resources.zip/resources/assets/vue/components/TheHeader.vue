<script lang="ts">
  import {Component, Vue} from 'vue-property-decorator';
  import {mapState} from 'vuex';

  //import TheMessageBadge from './TheMessageBadge.vue';
  import TheSettings from './TheSettings.vue';

  @Component({
    components: {
      TheSettings,
      //TheMessageBadge,
    },
    computed: {
      ...mapState(['backUrl', 'csrfToken', 'menu']),
    },
  })
  export default class TheHeader extends Vue {
    logout() {
      this.$auth.logout({makeRequest: true, redirect: {name: 'auth.login'},});
    }

    showSettings(): void {
      (<any>this.$refs.the_settings).$refs.modal.show();
    }

    goToPayments(){
      this.$router.push({path: '/payments'})
    }

    get homePath() {
      return this.$auth.user().home_path;
    }

    get path(): string {
      return this.$route.path;
    }
  }
</script>

<template lang="pug">
  div
    b-navbar.navbar-expand-lg.bg-light(type='light', style='background-color: #f8f9fa;')
      b-container(fluid="" )
        b-link.back-button.text-secondary(v-show='path !== homePath', :to='backUrl')
          v-icon(name='arrow-left')

        b-navbar-brand(:to='homePath', :class='{"has-back": path !== homePath}')
          img(
            style="width:48px"
            src='/images/qr1.svg',
            alt='Logo QRestaurant'
          )
          div(style="float: right;margin-top: 2px;")
            span.Gotham-Black.color-primary(style="font-size:1.3em;color:") Q-R
            span.Gotham-Medium.color-secondary(style="font-size:1.3em") estaurant


          //.font-caveat(style={fontSize: '1.2em', color: '#f16338'}) {{ $t('strings.project_title') }}


        b-navbar-toggle(target='nav_collapse')

        b-collapse#nav_collapse(is-nav)
          b-navbar-nav.ml-auto
            b-nav-item.menu(
              v-for='item in menu',
              :key='item.key',
              @click.prevent='item.handler',
              href='#',
            ) {{ $t(item.text) }}

            b-nav-item-dropdown(:text='$auth.user().user_name')
              b-dropdown-item(
                @click='showSettings',
              ) {{ $t('strings.settings') }}

              b-dropdown-item(
                @click='goToPayments',
              ) {{ $t('payments.title') }}

              b-dropdown-item(
                @click='logout',
              ) {{ $t('home.logout') }}
    the-settings(ref='the_settings')
</template>

<style scoped>
  .has-back {
    padding-left: 15px;
  }

</style>
