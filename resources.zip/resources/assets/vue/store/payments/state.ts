export default {
  fields: [
    {
      key: 'index',
      label: '#',
    },
    {
      key: 'user_name',
    },
    {
      key: 'status',
    },
    {
      key: 'payment_details',
    },
    {
      key: 'created_at',
    },
    {
      key: 'updated_at',
    },
    {
      key: 'actions',
    },
  ],
  status: [],
  payments: [],
  isLoading: false,
};
