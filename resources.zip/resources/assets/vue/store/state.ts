export default {
  appName: '',
  backUrl: '',
  csrfToken: '',
  homeItems: [],
  menu: [],
  settings: {},
  dialogMessage: '',
};
