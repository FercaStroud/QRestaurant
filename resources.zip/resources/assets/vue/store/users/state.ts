export default {
  users: [],
  pagination: {
    currentPage: 1,
    perPage: 5,
    totalUsers: 0,
    totalPages: 0,
  },
  isLoading: false,
  isModalLoading: false,
  isModalVisible: false,
};
