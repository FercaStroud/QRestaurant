import 'vue-awesome/icons/arrow-left';
import 'vue-awesome/icons/envelope';
import 'vue-awesome/icons/question-circle';
import 'vue-awesome/icons/pencil-alt';
import 'vue-awesome/icons/trash';
import 'vue-awesome/icons/users';
import 'vue-awesome/icons/lightbulb';
import 'vue-awesome/icons/brands/github';
