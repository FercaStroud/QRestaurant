<?php

return [
    'title'=>'Categories',
    'name'=>'Categories',
    'description'=>'Description',
    'image_src'=>'Image',
    'text'=>'Categories',
    'add_category' => 'Add category',
    'edit_category' => 'Edit category',
    'no_categories' => 'There are no registered categories.',
    'parent_name'=>'Parent category',

    'search' => 'Categories Search',

];
