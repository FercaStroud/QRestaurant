<?php

return [

    'add' => 'Add',
    'approve' => 'Approve',
    'cancel' => 'Cancel',
    'change_file' => 'Change file',
    'choose_file' => 'Choose file',
    'delete' => 'Delete',
    'edit' => 'Edit',
    'ok' => 'OK',
    'open' => 'Open',
    'publish' => 'Publish',
    'reject' => 'Reject',
    'save' => 'Save',
    'sending' => 'Sending',
    'update' => 'Update',
    'register' => '¡Register Now!',
    'search' => 'Search'

];
