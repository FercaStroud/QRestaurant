<?php

return [
    'title'=>'My Menus',
    'name' => 'Name',
    'add_menu' => 'Add Menu',
    'edit_menu' => 'Edit Menu',
    'description' => 'Description',
    'type' => 'Type',
    'file' => 'File',
    'add_file' => 'Add File',
    'view_file' => 'View File',
];
