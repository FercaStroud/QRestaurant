<?php

return [
    'text'=>'Products',
    'title'=>'Products',
    'add_product' => 'Add product',
    'edit_product' => 'Edit product',
    'no_products' => 'There are no registered products.',
    'image_src'=>'Image',
    'name'=>'Name',
    'category_name'=>'Category',
    'description'=>'Description',
    'price'=>'Price',
    'search' => 'Products Search',

];
