<?php

return [
    'cover_photo'=>'Cover Photo',
    'logo_photo'=>'Logo',
    'new_password' => 'New password',
    'password_confirmation' => 'Password confirmation',
];
