<?php

return [
    'title' => 'My Payments',
    'status' => 'Status',
    'service_status'=> 'Service Status',
    'details' => 'Detalles de pago'
];
