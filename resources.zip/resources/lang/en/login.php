<?php

return [

    'confirm_password' => 'Confirm password',
    'description' => '',
    'forgot_password' => 'Forgot Your Password?',
    'login' => 'Login',
    'keep_connected' => 'Keep me connected',
    'register' => 'Register',
    'reset_password' => 'Reset password',
    'send_reset_link' => 'Send the reset link',

    'account_created' => 'Your account has been created successfully.',

];
