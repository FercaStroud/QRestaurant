<?php

return [
    'dashboard_description' => 'Choose an option to continue.',
    'edit_cover_photo'=> 'Edit Cover Photo',
    'your_code' => 'Your QR code',
];
