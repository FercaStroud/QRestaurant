<?php

return [
    'cover_photo'=>'Imagen de portada',
    'logo_photo'=>'Logo',
    'new_password' => 'Nueva contraseña',
    'password_confirmation' => 'Confirmar contraseña',

];
