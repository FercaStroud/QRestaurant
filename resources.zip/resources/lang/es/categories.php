<?php

return [
    'title'=>'Categorías',
    'name'=>'Categorías',
    'description'=>'Descripción',
    'image_src'=>'Imagen',
    'text'=>'Categorías',
    'add_category' => 'Agregar categoría',
    'edit_category' => 'Editar categoría',
    'no_categories' => 'No hay categorías registradas',
    'parent_name'=>'Categoría padre',

    'search' => 'Búsqueda de categorías',

];
