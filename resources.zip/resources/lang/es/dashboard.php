<?php

return [
    'dashboard_description' => 'Selecciona una opción para continuar.',
    'edit_cover_photo'=> 'Modifica tu imagen de portada',
    'your_code' => 'Tu código QR es el siguiente',
];
