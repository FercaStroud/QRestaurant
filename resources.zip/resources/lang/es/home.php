<?php

return [

    'logout' => 'Cerrar sesión',
    'manage' => 'GESTIONAR',
    'welcome' => 'Bienvenido, :name',

];
