<?php

return [
    'text'=>'Productos',
    'title'=>'Productos',
    'add_product' => 'Agregar producto',
    'edit_product' => 'Editar producto',
    'no_products' => 'No hay productos registrados',
    'image_src'=>'Imagen actual',
    'name'=>'Nombre',
    'category_name'=>'Categoría',
    'description'=>'Descripción',
    'price'=>'Precio',
    'search' => 'Búsqueda de productos',
];
