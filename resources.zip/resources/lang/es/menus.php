<?php

return [
    'title'=>'Mis Menús',
    'name' => 'Nombre del Menú',
    'add_menu' => 'Agregar Menú',
    'edit_menu' => 'Modificar Menú',
    'description' => 'Descripción',
    'type' => 'Tipo de Menú',
    'file' => 'Archivo',
    'add_file' => 'Añadir Archivo',
    'view_file' => 'Ver Archivo',
];
