<?php

return [
    'title' => 'Mis pagos',
    'status' => 'Estado',
    'service_status'=> 'Estado del servicio',
    'details' => 'Detalles de pago'
];
